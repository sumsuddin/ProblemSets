#include <iostream>
#include <iomanip>
#include <fstream>
#include <vector>
#include <set>
#include <map>
using namespace std;

const int SZ = 100000 + 50;
const int MX = 200005;
int tree[8 * SZ];
long long sum[8 * SZ];

map<int, int> valueToIndMap;
map<int, int> indToValueMap;

struct Input {
    int op;
    int A;
    int B;
};

void build(int l, int h, int pos) {

    tree[pos] = 0;
    sum[pos] = 0;
    if (l != h) {
        build (l, (l+h)/2, pos*2);
        build ((l+h)/2 + 1, h, pos*2 + 1);
    }
}

void update(int l, int h, int pos, int updatePos, int sign) {
    if (l == h) {
        tree[pos] += sign;
        sum[pos] += (long long)indToValueMap[l] * (long long)sign;
        return;
    }

    if (updatePos <= (l+h)/2) {
        update(l, (l+h)/2, pos * 2, updatePos, sign);
    } else {
        update((l + h)/2 + 1, h, pos*2 + 1, updatePos, sign);
    }
    tree[pos] = tree[pos * 2] + tree[pos * 2 + 1];
    sum[pos] = sum[pos * 2] + sum[pos * 2 + 1];
}

int query(int l, int h, int pos, int queryPos) {

    if (l == h) {
        return indToValueMap[l];
    } else if (queryPos <= tree[pos * 2]) {
        return query(l, (l+h)/2, pos * 2, queryPos);
    } else {
        return query((l+h)/2 + 1, h, pos * 2 + 1, queryPos - tree[pos*2]);
    }
}

bool queryIsPresent(int l, int h, int pos, int qpos) {
    if (l == h) {
        return tree[pos] > 0;
    } else if (qpos <= (l+h)/2) {
        return queryIsPresent(l, (l + h)/2, pos * 2, qpos);
    } else {
        return queryIsPresent((l+h)/2 + 1, h, pos * 2 + 1, qpos);
    }
}

long long querySumL(int l, int h, int pos, int len) {
    if (l == h) {
        return (long long)indToValueMap[l] * (long long)len;
    } else if (len >= tree[pos * 2]) {
        return sum[pos * 2] + querySumL((l+h)/2 + 1, h, pos * 2 + 1, len - tree[pos * 2]);
    } else {
        return querySumL(l, (l+h)/2, pos * 2, len);
    }
}

long long querySumH(int l, int h, int pos, int len) {
    if (l == h) {
        return (long long)indToValueMap[l] * (long long)len;
    } else if (len >= tree[pos * 2 + 1]) {
        return querySumH(l, (l+h)/2, pos * 2, len - tree[pos * 2 + 1]) + sum[pos * 2 + 1];
    } else {
        return querySumH((l+h)/2 + 1, h, pos * 2 + 1, len);
    }
}

void solve() {
    //freopen("in.txt", "r", stdin);
    //freopen("out.txt", "w", stdout);
    int O;
    while (cin >> O) {
        build(0, MX, 1);

        valueToIndMap.clear();
        indToValueMap.clear();
        set<int> inputSet;
        vector<Input> inputVec;
        for (int i = 0; i < O; i++) {
            Input inp;
            cin >> inp.op;
            if (inp.op == 1) {
                cin >> inp.A;
                inputSet.insert(inp.A);
            } else if (inp.op == 2) {
                cin >> inp.A;
                inputSet.insert(inp.A);
            } else {
                cin >> inp.A >> inp.B;
                inputSet.insert(inp.A);
                inputSet.insert(inp.B);
            }
            inputVec.push_back(inp);
        }

        set<int>::iterator it = inputSet.begin();
        for (int i = 0; it != inputSet.end(); it++, i++) {
            int val = *it;
            valueToIndMap[val] = i;
            indToValueMap[i] = val;
        }
        for (int i = 0; i < O; i++){
            Input inp = inputVec[i];
            if (inp.op == 1) {
                update(0, MX, 1, valueToIndMap[inp.A], +1);
            } else if (inp.op == 2) {
                if (queryIsPresent(0, MX, 1, valueToIndMap[inp.A])) {
                    update(0, MX, 1, valueToIndMap[inp.A], -1);
                }
            } else {
                if (queryIsPresent(0, MX, 1, valueToIndMap[inp.A])) {
                    update(0, MX, 1, valueToIndMap[inp.A], -1);
                    update(0, MX, 1, valueToIndMap[inp.B], +1);
                }
            }
            int N = tree[1];
            if ((N & 1) == 0) {
                int mid1 = query(0, MX, 1, N/2);
                int mid2 = query(0, MX, 1, N/2 + 1);
                int len = N / 2;
                int total = len * mid1 - querySumL(0, MX, 1, len) + querySumH(0, MX, 1, len) - mid2 * len;
                cout << total << endl;
            } else {
                int mid = query(0, MX, 1, N / 2 + 1);
                int len = N / 2 + 1;
                int total = mid * len - querySumL(0, MX, 1, len) + querySumH(0, MX, 1, len) - mid * len;
                cout << total << endl;
            }
        }
    }
}

void check() {
    freopen("verdict.txt", "w", stdout);
    ifstream input1("out.txt");
    ifstream input2("out_alt.txt");

    int line = 0;
    while (true) {
        line++;
        string inputLine1;
        string inputLine2;


        if (!getline(input1, inputLine1)) {
            if (!getline(input2, inputLine2)) {
                cout << "Ok." << endl;
            } else {
                cout << "in1 ended first" << endl;
            }
            break;
        }
        if (!getline(input2, inputLine2)) {
            if (!getline(input1, inputLine1) && !getline(input2, inputLine2)) {
                cout << "Ok." << endl;
            } else {
                cout << "in2 ended first" << endl;
            }
            break;
        }

        if (inputLine1 != inputLine2) {
            cout << "Mismatch at " << line << " " << inputLine1 << " " << inputLine2 << endl;
            break;
        }
    }
    cout << "Total lines " << line << endl;
    input1.close();
    input2.close();
}

void generate() {
    ofstream ofstream("in.txt");
    int O = 100000;
    ofstream << O << endl;

    vector<int> inputVec;
    for (int i = 0; i < O; i++) {
        if (rand() % 100 >= 20) {
            int now = (rand() % 1000000000) + 1;
            ofstream << "1 " << now << endl;
            inputVec.push_back(now);
        } else {
            if (rand() % 100 >= 50) {
                ofstream << "2 ";
                if (rand() % 100 >= 50) {
                    ofstream << (rand() % 1000000000) + 1 << endl;
                } else {
                    ofstream << inputVec[rand() % inputVec.size()] << endl;
                }
            } else {
                ofstream << "3 ";

                if (rand() % 100 >= 50) {
                    ofstream << (rand() % 1000000000) + 1 << " ";
                } else {
                    int ind = rand() % inputVec.size();
                    ofstream << inputVec[ind] << " ";
                    inputVec.erase(inputVec.begin() + ind);
                }
                int now = (rand() % 1000000000) + 1;
                inputVec.push_back(now);
                ofstream << now << endl;
            }
        }
    }

    ofstream.close();
}

int main() {
    //generate();
    solve();
    //check();
    return 0;
}